package functionalExample;

@FunctionalInterface
public interface AddFive {

    public int apply(int number);
}
