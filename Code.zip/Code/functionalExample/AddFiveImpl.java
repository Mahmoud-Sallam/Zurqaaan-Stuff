package functionalExample;

public class AddFiveImpl implements AddFive {
    @Override
    public int apply(int number) {
        return number+5;
    }
}
