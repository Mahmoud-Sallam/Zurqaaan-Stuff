package functionalExample;

public interface BiIntFunction {

    public int apply(int x, int y);
}
