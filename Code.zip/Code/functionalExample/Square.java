package functionalExample;

public interface Square {

    public int apply(int x);
}
