package step3;

public enum Course {
    MATH,PHYSCICS,JAVA,CHEMISTRY,ENGLISH,ARABIC;
}
