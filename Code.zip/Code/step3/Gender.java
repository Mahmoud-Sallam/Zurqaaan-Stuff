package step3;

public enum Gender {
    MALE,FEMALE;
}
